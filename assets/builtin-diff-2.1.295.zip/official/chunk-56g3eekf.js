// @bun @bytecode
// Claude Code is a Beta product per Anthropic's Commercial Terms of Service.
// By using Claude Code, you agree that all code acceptance or rejection decisions you make,
// and the associated conversations in context, constitute Feedback under Anthropic's Commercial Terms,
// and may be used to improve Anthropic's products, including training models.
// You are responsible for reviewing any code suggestions before use.

// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.295
import{it}from"/$bunfs/root/chunk-tq2s6vn4.js";var rye="cc-plugin-diff";var Rrt=(o)=>it().loadedModules.find((e)=>e.name===o);var Z5=(o)=>Rrt(o)?.args;var J7=110,xrt=144;export{Rrt,Z5,J7,xrt,rye};
