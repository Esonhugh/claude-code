// @bun @bytecode
// Claude Code is a Beta product per Anthropic's Commercial Terms of Service.
// By using Claude Code, you agree that all code acceptance or rejection decisions you make,
// and the associated conversations in context, constitute Feedback under Anthropic's Commercial Terms,
// and may be used to improve Anthropic's products, including training models.
// You are responsible for reviewing any code suggestions before use.

// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.292
import{lt}from"/$bunfs/root/chunk-pgz2r7zp.js";var Kme="cc-plugin-diff";var NZe=(o)=>lt().loadedModules.find((e)=>e.name===o);var L4=(o)=>NZe(o)?.args;var sX=110,FZe=144;export{NZe,L4,sX,FZe,Kme};
